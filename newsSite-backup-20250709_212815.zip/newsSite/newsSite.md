# タイトル

## 概要

## 前提

## 内容

## 補足

## メモ

Vite プロジェクトを生成
https://ja.vite.dev/guide/
npm create vite@latest newsSite -- --template react-ts

MUI インストール
https://mui.com/material-ui/getting-started/installation/
デフォルトのインストール
npm install @mui/material @emotion/react @emotion/styled

Roboto フォント（400,700 を import）
npm install @fontsource/roboto

アイコン
npm install @mui/icons-material
