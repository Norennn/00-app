import { NewsItem, NewsCategory } from "../types";

// Hacker News APIのベースURL
const BASE_URL = "https://hacker-news.firebaseio.com/v0";

// 指定したカテゴリのニュースIDリストを取得する関数
export async function getNewsIds(category: NewsCategory): Promise<number[]> {
  const endpoints = {
    top: `${BASE_URL}/topstories.json`,
    new: `${BASE_URL}/newstories.json`,
    best: `${BASE_URL}/beststories.json`,
  };

  try {
    const response = await fetch(endpoints[category]);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const ids: number[] = await response.json();
    return ids;
  } catch (error) {
    console.error("ニュースIDの取得に失敗しました:", error);
    throw error;
  }
}

// 指定したIDのニュースの詳細を取得する関数
export async function getNewsItem(id: number): Promise<NewsItem> {
  try {
    const response = await fetch(`${BASE_URL}/item/${id}.json`);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const item: NewsItem = await response.json();
    return item;
  } catch (error) {
    console.error(`ニュースアイテム ${id} の取得に失敗しました:`, error);
    throw error;
  }
}

// 指定したカテゴリのニュースを取得する関数
export async function getNewsByCategory(
  category: NewsCategory,
  limit: number = 10,
  offset: number = 0
): Promise<{ items: NewsItem[]; totalCount: number }> {
  try {
    // ニュースIDリストを取得
    const allIds = await getNewsIds(category);

    // 指定した範囲のIDを取得
    const targetIds = allIds.slice(offset, offset + limit);

    // 各IDのニュースアイテムを取得
    const newsPromises = targetIds.map((id) => getNewsItem(id));
    const newsItems = await Promise.all(newsPromises);

    // ニュースアイテムと総件数を返す
    return {
      items: newsItems,
      totalCount: allIds.length,
    };
  } catch (error) {
    console.error("ニュースの取得に失敗しました:", error);
    throw error;
  }
}
