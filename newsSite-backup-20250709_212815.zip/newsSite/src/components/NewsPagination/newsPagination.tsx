import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";

interface NewsPaginationProps {
  currentPage: number;
  onPageChange: (page: number) => void;
  totalPages?: number;
}

export default function NewsPagination({
  currentPage,
  onPageChange,
  totalPages = 10,
}: NewsPaginationProps) {
  // ページが変更された時の処理
  const handlePageChange = (
    _event: React.ChangeEvent<unknown>,
    page: number
  ) => {
    // 親コンポーネントにページ変更を通知
    onPageChange(page);
  };

  // ページ数が0または1の場合はページネーションを表示しない
  if (totalPages <= 1) {
    return null;
  }

  return (
    <Stack sx={{ alignItems: "center", my: 2 }}>
      <Pagination
        count={totalPages}
        page={currentPage}
        onChange={handlePageChange}
        color="primary"
        size="large"
      />
    </Stack>
  );
}
