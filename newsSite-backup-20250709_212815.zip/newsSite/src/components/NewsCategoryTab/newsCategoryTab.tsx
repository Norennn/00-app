import * as React from "react";
import Box from "@mui/material/Box";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import { NewsCategory } from "../../types";

interface NewsCategoryTabProps {
  currentCategory: NewsCategory;
  onCategoryChange: (category: NewsCategory) => void;
}

export default function NewsCategoryTab({
  currentCategory,
  onCategoryChange,
}: NewsCategoryTabProps) {
  // ニュースのカテゴリのリスト
  const categories: NewsCategory[] = ["top", "new", "best"];

  // カテゴリに対応するラベルを取得
  const getCategoryLabel = (category: NewsCategory): string => {
    const labels = {
      top: "トップ",
      new: "新着",
      best: "ベスト",
    };
    return labels[category];
  };

  // 現在のカテゴリのタブインデックスを取得
  const currentTabIndex = categories.indexOf(currentCategory);

  // タブが変更された時の処理
  const handleChange = (_event: React.SyntheticEvent, newValue: number) => {
    // タブインデックスからカテゴリを取得
    const selectedCategory = categories[newValue];

    // 親に選択したカテゴリを渡す
    onCategoryChange(selectedCategory);
  };

  return (
    <Box sx={{ maxWidth: 960, mx: "auto", mt: 2 }}>
      <Tabs value={currentTabIndex} onChange={handleChange} centered>
        {categories.map((category) => (
          <Tab
            key={category}
            sx={{ flex: 1 }}
            label={getCategoryLabel(category)}
          />
        ))}
      </Tabs>
    </Box>
  );
}
