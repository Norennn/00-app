import { useState, useEffect } from "react";
import Box from "@mui/material/Box";
import List from "@mui/material/List";
import NewsItem from "../NewsItem/newsItem";
import LoadingCircle from "../LoadingCircle/loadingCircle";
import { NewsItem as NewsItemType, NewsCategory } from "../../types";
import { getNewsByCategory } from "../../lib/hackerNews";

interface NewsListProps {
  category: NewsCategory;
  currentPage: number;
  onTotalCountChange?: (totalCount: number) => void;
}

export default function NewsList({
  category,
  currentPage,
  onTotalCountChange,
}: NewsListProps) {
  // ニュースデータ
  const [newsItems, setNewsItems] = useState<NewsItemType[]>([]);
  // ローディング状態
  const [loading, setLoading] = useState<boolean>(true);
  // エラー状態
  const [error, setError] = useState<string | null>(null);

  // 1ページあたりの表示件数
  const ITEMS_PER_PAGE = 10;

  // ニュースデータを取得する関数
  const fetchNews = async (category: NewsCategory, page: number) => {
    try {
      setLoading(true);
      setError(null);

      // ページネーション用のオフセット計算
      const offset = (page - 1) * ITEMS_PER_PAGE;

      // APIからニュースデータと総件数を取得
      const result = await getNewsByCategory(category, ITEMS_PER_PAGE, offset);

      // 取得したデータを状態に設定
      setNewsItems(result.items);

      // 親コンポーネントに総件数を渡す
      if (onTotalCountChange) {
        onTotalCountChange(result.totalCount);
      }
    } catch (err) {
      // エラーが発生した場合の処理
      console.error("ニュースの取得に失敗しました:", err);
      setError("ニュースの取得に失敗しました");
    } finally {
      // ローディング状態を終了
      setLoading(false);
    }
  };

  // カテゴリまたはページが変更された時にニュースを取得
  useEffect(() => {
    fetchNews(category, currentPage);
  }, [category, currentPage]);

  // ローディング中の表示
  if (loading) {
    return <LoadingCircle />;
  }

  // エラーが発生した場合の表示
  if (error) {
    return (
      <Box
        sx={{
          maxWidth: 960,
          py: 2,
          px: 6,
          mt: 2,
          mx: "auto",
          bgcolor: "#eeeeee",
          textAlign: "center",
        }}
      >
        <p>{error}</p>
      </Box>
    );
  }

  // ニュースリストの表示
  return (
    <Box
      sx={{
        maxWidth: 960,
        py: 2,
        px: 6,
        mt: 2,
        mx: "auto",
        bgcolor: "#eeeeee",
      }}
    >
      <List sx={{ display: "flex", flexDirection: "column" }}>
        {newsItems.map((newsItem) => (
          <NewsItem key={newsItem.id} newsItem={newsItem} />
        ))}
      </List>
    </Box>
  );
}
