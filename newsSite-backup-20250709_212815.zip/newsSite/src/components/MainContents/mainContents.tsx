import { useState } from "react";
import NewsCategoryTab from "../NewsCategoryTab/newsCategoryTab";
import NewsList from "../NewsList/newsList";
import NewsPagination from "../NewsPagination/newsPagination";
import { NewsCategory } from "../../types";

export default function MainContents() {
  // 現在のカテゴリ
  const [currentCategory, setCurrentCategory] = useState<NewsCategory>("top");
  // 現在のページ
  const [currentPage, setCurrentPage] = useState<number>(1);
  // 総件数
  const [totalCount, setTotalCount] = useState<number>(0);

  // 1ページあたりの表示件数
  const ITEMS_PER_PAGE = 10;

  // 総ページ数を計算
  const totalPages = Math.ceil(totalCount / ITEMS_PER_PAGE);

  // カテゴリが変更された時の処理
  const handleCategoryChange = (category: NewsCategory) => {
    setCurrentCategory(category);
    // カテゴリが変更された時は1ページ目に戻す
    setCurrentPage(1);
  };

  // ページが変更された時の処理
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  // 総件数が変更された時の処理
  const handleTotalCountChange = (newTotalCount: number) => {
    setTotalCount(newTotalCount);

    // 現在のページが新しい総ページ数を超えている場合、最後のページに移動
    const newTotalPages = Math.ceil(newTotalCount / ITEMS_PER_PAGE);
    if (currentPage > newTotalPages && newTotalPages > 0) {
      setCurrentPage(newTotalPages);
    }
  };

  return (
    <>
      {/* カテゴリタブ */}
      <NewsCategoryTab
        currentCategory={currentCategory}
        onCategoryChange={handleCategoryChange}
      />

      {/* ニュースリスト */}
      <NewsList
        category={currentCategory}
        currentPage={currentPage}
        onTotalCountChange={handleTotalCountChange}
      />

      {/* ページネーション */}
      <NewsPagination
        currentPage={currentPage}
        onPageChange={handlePageChange}
        totalPages={totalPages}
      />
    </>
  );
}
