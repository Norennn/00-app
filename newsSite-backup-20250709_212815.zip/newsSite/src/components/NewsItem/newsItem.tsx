import Box from "@mui/material/Box";
import ListItem from "@mui/material/ListItem";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { NewsItem as NewsItemType } from "../../types";
import { formatNewsDate, isValidUrl } from "../../utils/dateUtils";

interface NewsItemProps {
  newsItem: NewsItemType;
}

export default function NewsItem({ newsItem }: NewsItemProps) {
  return (
    <ListItem
      sx={{
        bgcolor: "white",
        borderTop: "1px solid #aaaaaa",
        py: 1.5,
        px: 4,
        gap: 2,
      }}
    >
      <Box sx={{ flex: 1 }}>
        {/* 投稿時間を表示 */}
        <Typography variant="caption" gutterBottom sx={{ display: "block" }}>
          {formatNewsDate(newsItem.time)}
        </Typography>
        {/* ニュースタイトルを表示 */}
        <Typography sx={{ display: "block" }}>{newsItem.title}</Typography>
      </Box>
      {/* URLが有効な場合のみ詳細ボタンを表示 */}
      {isValidUrl(newsItem.url) && (
        <Button
          variant="outlined"
          component="a"
          href={newsItem.url}
          target="_blank"
          sx={{
            textDecoration: "none",
          }}
        >
          <Typography variant="button" sx={{ display: "block" }}>
            詳細
          </Typography>
        </Button>
      )}
    </ListItem>
  );
}
