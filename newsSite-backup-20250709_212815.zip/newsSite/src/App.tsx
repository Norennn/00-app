import Header from "./components/Header/header.tsx";
import MainContents from "./components/MainContents/mainContents.tsx";

function App() {
  return (
    <>
      <Header />
      <MainContents />
    </>
  );
}

export default App;
