// UNIX時間を変換する関数
export function formatNewsDate(timestamp: number): string {
  const date = new Date(timestamp * 1000);

  const month = date.getMonth() + 1;
  const day = date.getDate();
  const hours = date.getHours();
  const minutes = date.getMinutes();

  // 1桁の場合ゼロ埋めする
  const padZero = (num: number): string => num.toString().padStart(2, "0");

  return `${month}月${padZero(day)}日 ${padZero(hours)}時${padZero(minutes)}分`;
}

// ニュースのURLが有効かどうかを判定する関数
export function isValidUrl(url?: string): boolean {
  if (!url) return false;

  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
}
