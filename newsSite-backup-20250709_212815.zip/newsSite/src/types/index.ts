// Hacker News APIのニュースアイテムの型定義
export interface NewsItem {
  id: number;
  title: string;
  url?: string;
  time: number;
  score: number;
  by: string;
}

// ニュースのカテゴリ型定義
export type NewsCategory = "top" | "new" | "best";

// 全体用の型定義
export interface AppState {
  newsItems: NewsItem[];
  loading: boolean;
  currentCategory: NewsCategory;
  currentPage: number;
  totalPages: number;
}
